README

This is a eclipse project for assignment 2 object relationship.

./
  - bin/                    binary executable
  - src/                    source code
  - test/                   test data
  - class_diagram.png       class diagram
  - test_output.txt              sample test output
