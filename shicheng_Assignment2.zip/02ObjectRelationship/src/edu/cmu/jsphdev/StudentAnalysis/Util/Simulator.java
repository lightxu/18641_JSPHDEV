package edu.cmu.jsphdev.StudentAnalysis.Util;

/**
 * Abstract class for general simulator
 * @author shicheng
 *
 */
public abstract class Simulator {
	abstract void simulate(String simulateFileName);
}
