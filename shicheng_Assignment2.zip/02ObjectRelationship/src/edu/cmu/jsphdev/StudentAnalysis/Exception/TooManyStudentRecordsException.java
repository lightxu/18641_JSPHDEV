package edu.cmu.jsphdev.StudentAnalysis.Exception;

/**
 * 
 * @author shicheng
 *
 */
public class TooManyStudentRecordsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
