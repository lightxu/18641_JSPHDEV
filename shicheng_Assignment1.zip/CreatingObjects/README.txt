README

Coin.png: class diagram for Coin Toss Simulator
ParkingTicketSimulator.png: class diagram for Parking Ticket Simulator
Coin.txt: test output for Coin Toss Simulator
ParkingTicketSimulator.txt: test output for Parking Ticket Simulator
src: source code
bin: compiled class files

Author: Shicheng Xu
Andrew ID: shicheng
Email: shicheng@andrew.cmu.edu